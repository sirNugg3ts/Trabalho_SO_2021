#ifndef CLIENTE
#define CLIENTE

typedef struct player{
    int id;
    char nome[50];
    int pontuacao;
}PLAYER;

#endif