#ifndef JOGO
#define JOGO

#define DEFAULTDURACAO 10000 //temporario, enquanto não sabemos como processar o tempo de duração do jogo

typedef struct jogo{
    int idJogo;
    int duracao;
    int pontuacao;
}GAME;

#endif
