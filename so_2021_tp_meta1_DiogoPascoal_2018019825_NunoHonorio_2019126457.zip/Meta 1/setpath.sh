#!/bin/bash

export GAMEDIR="~/gamedir/"
export MAXPLAYERS=30
